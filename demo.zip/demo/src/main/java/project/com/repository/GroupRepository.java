package project.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import project.com.models.Group;

@Repository
public interface GroupRepository extends JpaRepository<Group, Long> {
}
