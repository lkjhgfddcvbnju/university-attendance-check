package project.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import project.com.models.Schedule;

import java.util.List;

@Repository
public interface ScheduleRepository extends JpaRepository<Schedule, Long> {
    List<Schedule> findByDayOfTheWeek(String dayOfTheWeek);

    @Modifying
    @Transactional
    @Query("UPDATE Schedule s SET s.lessons = :newLessons WHERE s.dayOfTheWeek = :dayOfTheWeek")
    List<String> updateLessonsByDayOfTheWeek(String dayOfTheWeek, List<String> newLessons);

}
