package project.com.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import project.com.FindEntityById;

@Configuration
@ComponentScan(basePackages = "project.com.mapper")
@ComponentScan(basePackageClasses = FindEntityById.class)
public class AppConfig {
}
