package project.com.configuration;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import project.com.models.*;
import project.com.repository.*;

import java.time.LocalDate;
import java.util.Collections;

@Configuration
public class DatabaseInitializer {

    @Bean
    CommandLineRunner initDatabase(
            GroupRepository groupRepository,
            TeacherRepository teacherRepository,
            StudentRepository studentRepository,
            ScheduleRepository scheduleRepository,
            LessonsRepository lessonsRepository,
            AttendanceRepository attendanceRepository) {
        return args -> {
            if (scheduleRepository.findAll().isEmpty()) {
                Schedule schedule = new Schedule();
                schedule.setDayOfTheWeek("Monday");
                scheduleRepository.save(schedule);

                Group group = new Group();
                group.setGroupNumber("First Group");
                group.setNumOfStudents(0);
                group.setSchedule(schedule);
                groupRepository.save(group);

                Teacher teacher = new Teacher();
                teacher.setFirstName("John");
                teacher.setLastName("Doe");
                teacher.setSchedule(schedule);
                teacherRepository.save(teacher);

                Lessons lesson = new Lessons();
                lesson.setLessonName("Mathematics");
                lesson.setClassStartTime("09:00");
                lesson.setClassFinishTime("10:00");
                lesson.setCabinet("101");
                lesson.setSchedule(schedule);
                lessonsRepository.save(lesson);

                Student student = new Student();
                student.setFirstName("Name");
                student.setLastName("Last Name");
                student.setGroup(group);
                studentRepository.save(student);

                Attendance attendance = new Attendance();
                attendance.setDate(LocalDate.now());
                attendance.setAttended(true);
                attendance.setTeacher(teacher);
                attendance.setStudent(student);
                attendanceRepository.save(attendance);

                group.setNumOfStudents(1);
                group.setStudents(Collections.singletonList(student));
                groupRepository.save(group);

                System.out.println("Database initialized successfully!");
            } else {
                System.out.println("Database already initialized, skipping...");
            }
        };
    }
}

