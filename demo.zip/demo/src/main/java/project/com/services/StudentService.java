package project.com.services;


import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import project.com.FindEntityById;
import project.com.dto.StudentDTO;
import project.com.mapper.*;
import project.com.models.Attendance;
import project.com.models.Group;
import project.com.models.Student;
import project.com.repository.AttendanceRepository;
import project.com.repository.StudentRepository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class StudentService {
    private final FindEntityById findEntityById;
    private final MapperToDTO toDTO;
    private final MapperToEntity toEntity;
    private final StudentRepository studRepo;
    private final AttendanceRepository attRepo;

    @Transactional
    public StudentDTO createStudent(StudentDTO studentDTO) {
        Student student = toEntity.toStudent(studentDTO);
        studRepo.save(student);

        return toDTO.toStudentDTO(student);
    }

    public StudentDTO getStudentById(Long studentId) {
        Student student = findEntityById.findStudentById(studentId);

        return toDTO.toStudentDTO(student);
    }

    public List<StudentDTO> getAllStudents() {
        List<Student> students = studRepo.findAll();
        if (students.isEmpty()) {
            System.out.println("No students found");
            return Collections.emptyList();
        }

        return students.stream()
                .map(toDTO::toStudentDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteStudent(Long studentId) {
        findEntityById.findStudentById(studentId);

        studRepo.deleteById(studentId);
    }

    @Transactional
    public StudentDTO updateStudent(Long studentId, StudentDTO studentDTO) {
        Student student = findEntityById.findStudentById(studentId);
        Group group = findEntityById.findGroupById(studentDTO.getGroupId());
        List<Attendance> attendances = attRepo.findAll();
        if (attendances.isEmpty()) {
            System.out.println("No attendances found");
            return null;
        }

        student.setFirstName(studentDTO.getFirstName());
        student.setLastName(studentDTO.getLastName());
        student.setGroup(group);
        student.setAttendance(attendances);

        studRepo.save(student);

        return toDTO.toStudentDTO(student);
    }
}

