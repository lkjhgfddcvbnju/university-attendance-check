package project.com.services;


import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import project.com.FindEntityById;
import project.com.dto.TeacherDTO;
import project.com.mapper.*;
import project.com.models.Attendance;
import project.com.models.Schedule;
import project.com.models.Teacher;
import project.com.repository.AttendanceRepository;
import project.com.repository.TeacherRepository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class TeacherService {
    private final FindEntityById findEntityById;
    private final MapperToDTO toDTO;
    private final MapperToEntity toEntity;
    private final TeacherRepository teacherRepo;
    private final AttendanceRepository attRepo;

    @Transactional
    public TeacherDTO createTeacher(TeacherDTO teacherDTO) {
        Teacher teacher = toEntity.toTeacher(teacherDTO);
        teacherRepo.save(teacher);

        return toDTO.toTeacherDTO(teacher);
    }

    public TeacherDTO getTeacherById(Long teacherId) {
        Teacher teacher = findEntityById.findTeacherById(teacherId);

        return toDTO.toTeacherDTO(teacher);
    }

    public List<TeacherDTO> getAllTeachers() {
        List<Teacher> teachers = teacherRepo.findAll();
        if (teachers.isEmpty()) {
            System.out.println("No teachers found");
            return Collections.emptyList();
        }

        return teachers.stream()
                .map(toDTO::toTeacherDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteTeacherById(Long teacherId) {
        findEntityById.findTeacherById(teacherId);

        teacherRepo.deleteById(teacherId);
    }

    @Transactional
    public TeacherDTO updateTeacherById(Long teacherId, TeacherDTO teacherDTO) {
        Teacher teacher = findEntityById.findTeacherById(teacherId);

        Schedule schedule = findEntityById.findScheduleById(teacherDTO.getScheduleId());
        List<Attendance> attendances = attRepo.findAll();
        if (attendances.isEmpty()) {
            System.out.println("No attendances found");
            return null;
        }

        teacher.setFirstName(teacherDTO.getFirstName());
        teacher.setLastName(teacherDTO.getLastName());
        teacher.setSchedule(schedule);
        teacher.setAttendance(attendances);

        teacherRepo.save(teacher);

        return toDTO.toTeacherDTO(teacher);
    }
}
