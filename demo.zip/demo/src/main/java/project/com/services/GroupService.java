package project.com.services;


import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import project.com.FindEntityById;
import project.com.dto.GroupDTO;
import project.com.mapper.*;
import project.com.models.Group;
import project.com.models.Schedule;
import project.com.models.Student;
import project.com.repository.GroupRepository;
import project.com.repository.StudentRepository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class GroupService {
    private final FindEntityById findEntityById;
    private final MapperToDTO toDTO;
    private final MapperToEntity toEntity;
    private final GroupRepository groupRepo;
    private final StudentRepository studRepo;

    @Transactional
    public GroupDTO createGroup(GroupDTO groupDTO) {
        Group group = toEntity.toGroup(groupDTO);
        groupRepo.save(group);

        return toDTO.toGroupDTO(group);
    }

    public GroupDTO getGroupById(Long groupId){
        Group group = findEntityById.findGroupById(groupId);

        return toDTO.toGroupDTO(group);
    }

    public List<GroupDTO> getAllGroups(){
        List<Group> groups = groupRepo.findAll();
        if (groups.isEmpty()){
            System.out.println("No groups found");
            return Collections.emptyList();
        }

        return groups.stream()
                .map(toDTO::toGroupDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteGroupById(Long groupId){
        findEntityById.findGroupById(groupId);

        groupRepo.deleteById(groupId);
    }

    @Transactional
    public GroupDTO updateGroup(Long groupId,GroupDTO updatedGroupDTO) {
        Schedule schedule = findEntityById.findScheduleById(groupId);
        List<Student> students = studRepo.findAll();
        if(students.isEmpty()){
            System.out.println("No students found with the given id: " + groupId);
            return null;
        }

        Group group = findEntityById.findGroupById(groupId);
        group.setGroupNumber(updatedGroupDTO.getGroupNumber());
        group.setNumOfStudents(updatedGroupDTO.getNumOfStudents());
        group.setStudents(students);
        group.setSchedule(schedule);

        groupRepo.save(group);

        return toDTO.toGroupDTO(group);

    }
}
