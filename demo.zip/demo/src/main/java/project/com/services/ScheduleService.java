package project.com.services;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import project.com.FindEntityById;
import project.com.dto.ScheduleDTO;
import project.com.mapper.*;
import project.com.models.*;
import project.com.repository.GroupRepository;
import project.com.repository.LessonsRepository;
import project.com.repository.ScheduleRepository;
import project.com.repository.TeacherRepository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ScheduleService {
    private final FindEntityById findEntityById;
    private final MapperToDTO toDTO;
    private final MapperToEntity toEntity;
    private final ScheduleRepository schRepo;
    private final GroupRepository groupRepo;
    private final TeacherRepository teacherRepo;
    private final LessonsRepository lessonsRepo;

    @Transactional
    public ScheduleDTO createSchedule(ScheduleDTO scheduleDTO) {
        Schedule schedule = toEntity.toSchedule(scheduleDTO);
        schRepo.save(schedule);

        return toDTO.toScheduleDTO(schedule);
    }

    public ScheduleDTO getScheduleById(Long scheduleId){
        Schedule schedule = findEntityById.findScheduleById(scheduleId);

        return toDTO.toScheduleDTO(schedule);
    }

    public List<ScheduleDTO> getAllSchedules(){
        List<Schedule> schedules = schRepo.findAll();
        if (schedules.isEmpty()){
            System.out.println("No schedules found");
            return Collections.emptyList();
        }

        return schedules.stream()
                .map(toDTO::toScheduleDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteScheduleById(Long scheduleId){
        findEntityById.findScheduleById(scheduleId);

        schRepo.deleteById(scheduleId);
    }

    @Transactional
    public ScheduleDTO updateSchedule(Long scheduleId, ScheduleDTO scheduleDTO){
        Schedule schedule = findEntityById.findScheduleById(scheduleId);
        List<Group> groups = groupRepo.findAll();
        if(groups.isEmpty()){
            System.out.println("No groups found with the given id: " + scheduleId);
            return null;
        }
        List<Teacher> teachers = teacherRepo.findAll();
        if (teachers.isEmpty()){
            System.out.println("No teachers found with the given id: " + scheduleId);
            return null;
        }
        List<Lessons> lessons = lessonsRepo.findAll();
        if (lessons.isEmpty()){
            System.out.println("No lessons found with the given id: " + scheduleId);
            return null;
        }

        schedule.setDayOfTheWeek(scheduleDTO.getDayOfTheWeek());
        schedule.setGroups(groups);
        schedule.setTeachers(teachers);
        schedule.setLessons(lessons);

        schRepo.save(schedule);

        return toDTO.toScheduleDTO(schedule);
    }
}
