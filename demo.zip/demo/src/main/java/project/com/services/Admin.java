/*
package project.com.services;

import project.com.repository.AdminRepository;

public class Admin {
    private final AdminRepository adminRepository;

    public Admin(AdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

}
*/
