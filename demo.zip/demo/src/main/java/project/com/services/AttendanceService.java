package project.com.services;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import project.com.FindEntityById;
import project.com.dto.AttendanceDTO;
import project.com.mapper.MapperToDTO;
import project.com.mapper.MapperToEntity;
import project.com.models.Attendance;
import project.com.models.Student;
import project.com.models.Teacher;
import project.com.repository.AttendanceRepository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class AttendanceService {
    private final FindEntityById findEntityById;
    private final AttendanceRepository attendanceRepository;
    private final MapperToDTO toDTO;
    private final MapperToEntity toEntity;

    @Transactional
    public AttendanceDTO createAttendance(AttendanceDTO attendanceDTO){

        Attendance attendance = toEntity.toAttendance(attendanceDTO);
        Attendance savedAttendance = attendanceRepository.save(attendance);

        return toDTO.toAttendanceDTO(savedAttendance);
    }

    public AttendanceDTO getAttendanceById(Long attendanceId){
        Attendance attendance = findEntityById.findAttendanceById(attendanceId);
        return toDTO.toAttendanceDTO(attendance);
    }

    public List<AttendanceDTO> getAllAttendances(){
        List<Attendance> attendances = attendanceRepository.findAll();
        if (attendances.isEmpty()){
            System.out.println("No Attendances found");
            return Collections.emptyList();
        }
        return attendances.stream().map(toDTO::toAttendanceDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteAttendanceById(Long attendanceId){
        findEntityById.findAttendanceById(attendanceId);

        attendanceRepository.deleteById(attendanceId);
    }

    @Transactional
    public AttendanceDTO updateAttendance(Long attendanceId, AttendanceDTO updatedAttendance){
        Attendance attendance = findEntityById.findAttendanceById(attendanceId);
        Teacher teacher = findEntityById.findTeacherById(updatedAttendance.getTeacherId());
        Student student = findEntityById.findStudentById(updatedAttendance.getStudentId());


        attendance.setAttended(updatedAttendance.isAttended());
        attendance.setDate(updatedAttendance.getDate());
        attendance.setTeacher(teacher);
        attendance.setStudent(student);

        Attendance savedAttendance = attendanceRepository.save(attendance);

        return toDTO.toAttendanceDTO(savedAttendance);
    }
}

