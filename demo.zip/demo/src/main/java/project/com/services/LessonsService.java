package project.com.services;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import project.com.dto.LessonsDTO;
import project.com.mapper.*;
import project.com.FindEntityById;
import project.com.models.Lessons;
import project.com.models.Schedule;
import project.com.repository.LessonsRepository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class LessonsService {
    private final FindEntityById findEntityById;
    private final LessonsRepository lesRepo;
    private final MapperToDTO toDTO;
    private final MapperToEntity toEntity;

    @Transactional
    public LessonsDTO createLesson(LessonsDTO lessonsDTO) {
        Lessons lessons = toEntity.toLessons(lessonsDTO);
        lesRepo.save(lessons);

        return toDTO.toLessonsDTO(lessons);
    }

    public LessonsDTO findLessonById(Long id) {
        Lessons lessons = findEntityById.findLessonById(id);

        return toDTO.toLessonsDTO(lessons);
    }

    public List<LessonsDTO> findAllLessons() {
        List<Lessons> lessons = lesRepo.findAll();
        if (lessons.isEmpty()) {
            System.out.println("No lessons found");
            return Collections.emptyList();
        }

        return lessons.stream()
                .map(toDTO::toLessonsDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteLesson(Long id) {
        findEntityById.findLessonById(id);

        lesRepo.deleteById(id);
    }

    @Transactional
    public LessonsDTO updateLesson(Long lessonId, LessonsDTO lessonsDTO) {
        Lessons lessons = findEntityById.findLessonById(lessonId);
        Schedule schedule = findEntityById.findScheduleById(lessonsDTO.getScheduleId());

        lessons.setLessonName(lessonsDTO.getLessonName());
        lessons.setClassStartTime(lessonsDTO.getClassStartTime());
        lessons.setClassFinishTime(lessonsDTO.getClassFinishTime());
        lessons.setCabinet(lessonsDTO.getCabinet());
        lessons.setSchedule(schedule);

        lesRepo.save(lessons);

        return toDTO.toLessonsDTO(lessons);
    }
}
