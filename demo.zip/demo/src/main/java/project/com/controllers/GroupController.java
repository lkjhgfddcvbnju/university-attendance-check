package project.com.controllers;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.com.dto.GroupDTO;
import project.com.services.GroupService;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/group")
public class GroupController {
    private final GroupService groupService;

    @PostMapping("/createGroup")
    public ResponseEntity<GroupDTO> createGroup(@RequestBody GroupDTO groupDTO) {
        GroupDTO group = groupService.createGroup(groupDTO);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(group);
    }

    @GetMapping("/getGroupById/{id}")
    public ResponseEntity<GroupDTO> getGroupById(@PathVariable("id") Long groupId){
        GroupDTO group = groupService.getGroupById(groupId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(group);
    }

    @GetMapping("/getAllGroups")
    public ResponseEntity<List<GroupDTO>> getAllGroups(){
        List<GroupDTO> groups = groupService.getAllGroups();

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(groups);
    }

    @PutMapping("/updateGroup/{id}")
    public ResponseEntity<GroupDTO> updateGroup(@PathVariable("id") Long groupId, @RequestBody GroupDTO groupDTO){
        GroupDTO updatedGroup = groupService.updateGroup(groupId, groupDTO);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(updatedGroup);
    }

    @DeleteMapping("/deleteGroup/{id}")
    public ResponseEntity<String> deleteGroup(@PathVariable("id") Long groupId){
        groupService.deleteGroupById(groupId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body("Group deleted successfully");
    }

}
