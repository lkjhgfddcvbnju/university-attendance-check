package project.com.controllers;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.com.dto.LessonsDTO;
import project.com.services.LessonsService;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/lesson")
public class LessonController {
    private final LessonsService lsnService;

    @PostMapping("/createLesson")
    public ResponseEntity<LessonsDTO> createLesson(@RequestBody LessonsDTO lessonsDTO){
        LessonsDTO createdLesson = lsnService.createLesson(lessonsDTO);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(createdLesson);
    }

    @GetMapping("/getLesson/{id}")
    public ResponseEntity<LessonsDTO> getLessonById(@PathVariable("id") Long lessonId){
        LessonsDTO lesson = lsnService.findLessonById(lessonId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(lesson);
    }

    @GetMapping("/getAllLessons")
    public ResponseEntity<List<LessonsDTO>> getAllLessons(){
        List<LessonsDTO> lessonsList = lsnService.findAllLessons();

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(lessonsList);
    }

    @PutMapping("/updateLesson/{id}")
    public ResponseEntity<LessonsDTO> updateLesson(@PathVariable("id") Long lessonId, @RequestBody LessonsDTO lessonsDTO){
        LessonsDTO updatedLesson = lsnService.updateLesson(lessonId, lessonsDTO);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(updatedLesson);
    }

    @DeleteMapping("/deleteLesson/{id}")
    public ResponseEntity<String> deleteLesson(@PathVariable("id") Long lessonId){
        lsnService.deleteLesson(lessonId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body("Lesson deleted successfully");
    }
}
