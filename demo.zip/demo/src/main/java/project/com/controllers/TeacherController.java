package project.com.controllers;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.com.dto.TeacherDTO;
import project.com.services.TeacherService;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/teacher")
public class TeacherController {
    private final TeacherService teacherService;

    @PostMapping("/createTeacher")
    public ResponseEntity<TeacherDTO> createTeacher(
            @RequestBody TeacherDTO teacherDTO) {
        TeacherDTO teacher = teacherService
                .createTeacher(teacherDTO);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(teacher);
    }

    @GetMapping("/getTeacher/{id}")
    public ResponseEntity<TeacherDTO> getTeacherById(
            @PathVariable("id") Long teacherId
    ){
        TeacherDTO teacher = teacherService
                .getTeacherById(teacherId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(teacher);
    }

    @GetMapping("/getAllTeachers")
    public ResponseEntity<List<TeacherDTO>> getAllTeachers() {
        List<TeacherDTO> teachers = teacherService
                .getAllTeachers();

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(teachers);
    }

    @PutMapping("/updateTeacher/{id}")
    public ResponseEntity<TeacherDTO> updateTeacher(
            @PathVariable("id") Long teacherId,
            @RequestBody TeacherDTO teacherDTO
    ){
        TeacherDTO updatedTeacher = teacherService
                .updateTeacherById(teacherId, teacherDTO);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(updatedTeacher);
    }

    @DeleteMapping("/deleteTeacher/{id}")
    public ResponseEntity<String> deleteTeacher(
            @PathVariable("id") Long teacherId
    ){
        teacherService.deleteTeacherById(teacherId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body("Teacher deleted successfully");
    }
}
