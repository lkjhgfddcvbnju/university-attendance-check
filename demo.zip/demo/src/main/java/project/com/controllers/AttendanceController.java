package project.com.controllers;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.com.dto.AttendanceDTO;
import project.com.services.AttendanceService;

import java.util.List;

@AllArgsConstructor
@RestController
public class AttendanceController {
    private final AttendanceService atnService;

    @PostMapping("/attendance/createAttendance")
    public ResponseEntity<AttendanceDTO> createAttendance(@RequestBody AttendanceDTO attendanceDTO){
        AttendanceDTO savedAtn = atnService.createAttendance(attendanceDTO);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(savedAtn);
    }

    @GetMapping("/attendance/getAttendanceById/{id}")
    public ResponseEntity<AttendanceDTO> getAtnById(@PathVariable("id") Long atnId){
        AttendanceDTO savedAtn = atnService.getAttendanceById(atnId);
        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(savedAtn);
    }

    @GetMapping("/attendance/getAllAttendances")
    public ResponseEntity<List<AttendanceDTO>> getAllAttendances(){
        List<AttendanceDTO> atnList = atnService.getAllAttendances();
        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(atnList);
    }

    @PutMapping("/attendance/updateAttendance/{id}")
    public ResponseEntity<AttendanceDTO> updateAttendance(@PathVariable("id") Long atnId,
                                                          @RequestBody AttendanceDTO atnDTO){
        AttendanceDTO updatedAtn = atnService.updateAttendance(atnId, atnDTO);
        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(updatedAtn);
    }

    @DeleteMapping("/attendance/deleteAttendanceById/{id}")
    public ResponseEntity<String> deleteAtnById(@PathVariable("id") Long atnId){
        atnService.deleteAttendanceById(atnId);
        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body("Attendance deleted");
    }
}
