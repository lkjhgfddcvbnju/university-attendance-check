package project.com.controllers;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.com.dto.ScheduleDTO;
import project.com.services.ScheduleService;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/schedule")
public class ScheduleController {
    private final ScheduleService scheduleService;

    @PostMapping("/createSchedule")
    public ResponseEntity<ScheduleDTO> createSchedule(@RequestBody ScheduleDTO scheduleDTO){
        ScheduleDTO savedSchedule = scheduleService
                .createSchedule(scheduleDTO);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(savedSchedule);
    }

    @GetMapping("/getSchedule/{id}")
    public ResponseEntity<ScheduleDTO> getScheduleById(
            @PathVariable("id") Long scheduleId
    ){
        ScheduleDTO schedule = scheduleService
                .getScheduleById(scheduleId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(schedule);
    }

    @GetMapping("/getAllSchedule")
    public ResponseEntity<List<ScheduleDTO>> getAllSchedules(){
        List<ScheduleDTO> scheduleList = scheduleService
                .getAllSchedules();

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(scheduleList);
    }

    @PutMapping("/updateSchedule/{id}")
    public ResponseEntity<ScheduleDTO> updateSchedule(
            @PathVariable("id") Long scheduleId,
            @RequestBody ScheduleDTO scheduleDTO){
        ScheduleDTO updatedSchedule = scheduleService
                .updateSchedule(scheduleId, scheduleDTO);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(updatedSchedule);
    }

    @DeleteMapping("/deleteSchedule/{id}")
    public ResponseEntity<String> deleteSchedule(
            @PathVariable("id") Long scheduleId
    ){
        scheduleService.deleteScheduleById(scheduleId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body("Schedule deleted successfully");
    }
}
