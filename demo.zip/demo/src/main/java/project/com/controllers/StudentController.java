package project.com.controllers;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.com.dto.StudentDTO;
import project.com.services.StudentService;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/student")
public class StudentController {
    private final StudentService studentService;

    @PostMapping("/createStudent")
    public ResponseEntity<StudentDTO> createStudent(
            @RequestBody StudentDTO studentDTO
    ){
        StudentDTO createdStudent = studentService
                .createStudent(studentDTO);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(createdStudent);
    }

    @GetMapping("/getStudent/{id}")
    public ResponseEntity<StudentDTO> getStudentById(
            @PathVariable("id") Long studentId
    ){
        StudentDTO student = studentService
                .getStudentById(studentId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(student);
    }

    @GetMapping("/getAllStudent")
    public ResponseEntity<List<StudentDTO>> getAllStudent(){
        List<StudentDTO> students = studentService
                .getAllStudents();

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(students);
    }

    @PutMapping("/updateStudent/{id}")
    public ResponseEntity<StudentDTO> updateStudentById(
            @PathVariable("id") Long studentId,
            @RequestBody StudentDTO studentDTO
    ){
        StudentDTO updatedStudent = studentService
                .updateStudent(studentId, studentDTO);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body(updatedStudent);
    }

    @DeleteMapping("/deleteStudent/{id}")
    public ResponseEntity<String> deleteStudentById(
            @PathVariable("id") Long studentId
    ){
        studentService.deleteStudent(studentId);

        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .body("Student deleted successfully");
    }
}
