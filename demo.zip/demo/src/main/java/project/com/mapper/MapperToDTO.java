package project.com.mapper;

import lombok.Data;
import org.springframework.stereotype.Component;
import project.com.dto.*;
import project.com.models.*;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
public class MapperToDTO {

    public AttendanceDTO toAttendanceDTO(Attendance attendance){
        return new AttendanceDTO(
                attendance.getAttendance_id(),
                attendance.isAttended(),
                attendance.getDate(),
                attendance.getTeacher() != null ? attendance.getTeacher().getTeacher_id() : null,
                attendance.getStudent() != null ? attendance.getStudent().getStudent_id() : null

        );
    }

    public GroupDTO toGroupDTO(Group group){
        List<Student> students = group.getStudents();
        List<Long> idList = new ArrayList<>();
        if (students != null && !students.isEmpty()) {
                for (Student student : students) {
                    idList.add(student.getStudent_id());
                }
            } else {
                idList = new ArrayList<>();
            }

        return new GroupDTO(
                group.getGroup_id(),
                group.getGroupNumber(),
                group.getNumOfStudents(),
                idList,
                group.getSchedule() != null ?group.getSchedule().getSchedule_id() : null
        );
    }

    public LessonsDTO toLessonsDTO(Lessons lessons){
        return new LessonsDTO(
                lessons.getLessons_id(),
                lessons.getLessonName(),
                lessons.getClassStartTime(),
                lessons.getClassFinishTime(),
                lessons.getCabinet(),
                lessons.getSchedule() != null ? lessons.getSchedule().getSchedule_id() : null
        );
    }

    public ScheduleDTO toScheduleDTO(Schedule schedule){
        List<Group> groups = schedule.getGroups();
        List<Long> idGroups = new ArrayList<>();
        if (groups != null && !groups.isEmpty()){
            for (Group group : groups) {
                idGroups.add(group.getGroup_id());
            }
        } else {
            idGroups = new ArrayList<>();
        }

        List<Teacher> teachers = schedule.getTeachers();
        List<Long> idTeachers = new ArrayList<>();
        if (teachers != null && !teachers.isEmpty()){
            for (Teacher teacher : teachers) {
                idTeachers.add(teacher.getTeacher_id());
            }
        } else {
            idTeachers = new ArrayList<>();
        }

        List<Lessons> lessons = schedule.getLessons();
        List<Long> idLessons = new ArrayList<>();
        if (lessons != null && !lessons.isEmpty()){
            for (Lessons lesson : lessons) {
                idLessons.add(lesson.getLessons_id());
            }
        } else {
            idLessons = new ArrayList<>();
        }

        return new ScheduleDTO(
                schedule.getSchedule_id(),
                schedule.getDayOfTheWeek(),
                idGroups,
                idTeachers,
                idLessons
        );
    }

    public StudentDTO toStudentDTO(Student student){
        List<Attendance> attendances = student.getAttendance();
        List<Long> idAttendances = new ArrayList<>();
        if(attendances != null && !attendances.isEmpty()){
            for (Attendance attendance : attendances) {
                idAttendances.add(attendance.getAttendance_id());
            }
        } else {
            idAttendances = new ArrayList<>();
        }

        return new StudentDTO(
                student.getStudent_id(),
                student.getFirstName(),
                student.getLastName(),
                student.getGroup() != null ? student.getGroup().getGroup_id() : null,
                idAttendances

        );
    }

    public TeacherDTO toTeacherDTO(Teacher teacher){
        List<Attendance> attendances = teacher.getAttendance();
        List<Long> idAttendances = new ArrayList<>();
        if(attendances != null && !attendances.isEmpty()){
            for (Attendance attendance : attendances) {
                idAttendances.add(attendance.getAttendance_id());
            }
        } else {
            idAttendances = new ArrayList<>();
        }

        return new TeacherDTO(
                teacher.getTeacher_id(),
                teacher.getFirstName(),
                teacher.getLastName(),
                teacher.getSchedule() != null ? teacher.getSchedule().getSchedule_id() : null,
                idAttendances
        );
    }
}
