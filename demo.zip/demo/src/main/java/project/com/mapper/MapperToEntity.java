package project.com.mapper;

import lombok.Data;
import org.springframework.stereotype.Component;
import project.com.FindEntityById;
import project.com.dto.*;
import project.com.models.*;
import project.com.repository.*;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
public class MapperToEntity {
    private final FindEntityById findEntityById;
    private final TeacherRepository teacherRepository;
    private final StudentRepository studentRepository;
    private final AttendanceRepository attendanceRepository;
    private final ScheduleRepository scheduleRepository;
    private final GroupRepository groupRepository;
    private final LessonsRepository lessonsRepository;

    public  Attendance toAttendance(AttendanceDTO attendanceDTO){
        Teacher teacher = findEntityById.findTeacherById(attendanceDTO.getTeacherId());
        Student student = findEntityById.findStudentById(attendanceDTO.getStudentId());

        Attendance attendance = new Attendance();
        attendance.setAttended(attendanceDTO.isAttended());
        attendance.setDate(attendanceDTO.getDate());
        attendance.setTeacher(teacher);
        attendance.setStudent(student);
        return attendance;
    }

    public Group toGroup(GroupDTO groupDTO){
        List<Student> studentList = studentRepository.findAll();
        if (studentList.isEmpty()){
            studentList = new ArrayList<>();
        }
        Schedule schedule = findEntityById.findScheduleById(groupDTO.getScheduleId());

        Group group = new Group();
        group.setGroupNumber(groupDTO.getGroupNumber());
        group.setNumOfStudents(groupDTO.getNumOfStudents());
        group.setStudents(studentList);
        group.setSchedule(schedule);
        return group;
    }

    public Lessons toLessons(LessonsDTO lessonsDTO){
        Schedule schedule = findEntityById.findScheduleById(lessonsDTO.getScheduleId());

        Lessons lessons = new Lessons();
        lessons.setLessonName(lessonsDTO.getLessonName());
        lessons.setClassStartTime(lessonsDTO.getClassStartTime());
        lessons.setClassFinishTime(lessonsDTO.getClassFinishTime());
        lessons.setCabinet(lessonsDTO.getCabinet());
        lessons.setSchedule(schedule);
        return lessons;
    }

    public Schedule toSchedule(ScheduleDTO scheduleDTO){
        List<Group> groupList = groupRepository.findAll();
        if(groupList.isEmpty()){
            groupList = new ArrayList<>();
        }
        List<Teacher> teacherList = teacherRepository.findAll();
        if (teacherList.isEmpty()){
            teacherList = new ArrayList<>();
        }
        List<Lessons> lessonlist = lessonsRepository.findAll();
        if (lessonlist.isEmpty()){
            lessonlist = new ArrayList<>();
        }

        Schedule schedule = new Schedule();
        schedule.setDayOfTheWeek(scheduleDTO.getDayOfTheWeek());
        schedule.setGroups(groupList);
        schedule.setTeachers(teacherList);
        schedule.setLessons(lessonlist);
        return schedule;
    }

    public Student toStudent(StudentDTO studentDTO){
        Group group = findEntityById.findGroupById(studentDTO.getGroupId());

        List<Attendance> attendanceList = attendanceRepository.findAll();
        if (attendanceList.isEmpty()){
            attendanceList = new ArrayList<>();
        }

        Student student = new Student();
        student.setFirstName(studentDTO.getFirstName());
        student.setLastName(studentDTO.getLastName());
        student.setGroup(group);
        student.setAttendance(attendanceList);
        return student;
    }

    public Teacher toTeacher(TeacherDTO teacherDTO){
        Schedule schedule = findEntityById.findScheduleById(teacherDTO.getScheduleId());
        List<Attendance> attendanceList = attendanceRepository.findAll();
        if (attendanceList.isEmpty()){
            attendanceList = new ArrayList<>();
        }

        Teacher teacher = new Teacher();
        teacher.setFirstName(teacherDTO.getFirstName());
        teacher.setLastName(teacherDTO.getLastName());
        teacher.setSchedule(schedule);
        teacher.setAttendance(attendanceList);
        return teacher;
    }
}
