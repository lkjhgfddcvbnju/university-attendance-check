package project.com.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AttendanceDTO {
    private Long attendanceId;
    private boolean attended;
    private LocalDate date;
    private Long teacherId;
    private Long studentId;
}
