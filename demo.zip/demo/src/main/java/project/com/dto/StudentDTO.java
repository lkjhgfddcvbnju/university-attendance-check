package project.com.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class StudentDTO {
    private Long studentId;
    private String firstName;
    private String lastName;
    private Long groupId;
    private List<Long> attendanceId;
}
