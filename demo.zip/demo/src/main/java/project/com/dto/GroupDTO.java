package project.com.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class GroupDTO {
    private Long groupId;
    private String groupNumber;
    private int numOfStudents;
    private List<Long> studentId;
    private Long scheduleId;
}
