package project.com.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class TeacherDTO {
    private Long teacherId;
    private String firstName;
    private String lastName;
    private Long scheduleId;
    private List<Long> attendanceId;
}
