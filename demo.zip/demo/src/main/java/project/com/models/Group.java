package project.com.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "groups")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Group {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long group_id;

    @Column(name = "group_number")
    private String groupNumber;

    @Column(name = "num_of_students")
    private int numOfStudents;

    @OneToMany(mappedBy = "group", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Student> students = new ArrayList<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "schedule_id")
    private Schedule schedule;

    public Group(String groupNumber, List<Student> students, Schedule schedule) {
        this.numOfStudents = students.size();
        this.groupNumber = groupNumber;
        this.students = students;
        this.schedule = schedule;
    }

    public void addStudent(Student student) {
        student.setGroup(this);
        students.add(student);
    }

    public void removeStudent(Student student) {
        students.remove(student);
    }

    @Override
    public String toString() {
        return "Group{" +
                "group_id=" + group_id +
                ", groupNumber='" + groupNumber + '\'' +
                ", numOfStudents=" + numOfStudents +
                ", students=" + students +
                '}';
    }
}
