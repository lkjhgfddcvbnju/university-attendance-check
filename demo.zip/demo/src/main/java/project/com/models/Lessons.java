package project.com.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "lessons")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Lessons {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long lessons_id;

    @Column(name = "name_of_lesson")
    private String lessonName;

    @Column(name = "class_start_time")
    private String classStartTime;

    @Column(name = "class_finish_time")
    private String classFinishTime;

    private String cabinet;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "schedule_id")
    private Schedule schedule;

    public Lessons(String lessonName, String classStartTime, String classFinishTime, String cabinet) {
        this.lessonName = lessonName;
        this.classStartTime = classStartTime;
        this.classFinishTime = classFinishTime;
        this.cabinet = cabinet;
    }

    @Override
    public String toString() {
        return "Lessons{" +
                "lessonsId=" + lessons_id +
                ", lessonName='" + lessonName + '\'' +
                ", classStartTime='" + classStartTime + '\'' +
                ", classFinishTime='" + classFinishTime + '\'' +
                ", cabinet='" + cabinet + '\'' +
                '}';
    }
}
