package project.com;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.stereotype.Component;
import project.com.models.*;
import project.com.repository.*;

import java.time.LocalDate;
import java.util.ArrayList;


@Data
@AllArgsConstructor
@Component
public class FindEntityById {
    private final AttendanceRepository aRepo;
    private final GroupRepository gRepo;
    private final LessonsRepository lRepo;
    private final ScheduleRepository shedRepo;
    private final StudentRepository stRepo;
    private final TeacherRepository tRepo;

    public Attendance findAttendanceById(Long attendanceId){
        return aRepo.findById(attendanceId)
                .orElseGet(() -> {
                    Attendance newAttendance = new Attendance();
                    newAttendance.setDate(LocalDate.now());
                    return aRepo.save(newAttendance);
                });
    }

    public Group findGroupById(Long groupId){
        return gRepo.findById(groupId)
                .orElseGet(() -> {
                            Group newGroup = new Group();
                            newGroup.setGroupNumber("Default Group");
                            newGroup.setNumOfStudents(0);
                            return gRepo.save(newGroup);
                        });
    }

    public Lessons findLessonById(Long lessonId){
        return lRepo.findById(lessonId)
                .orElseGet(() -> {
                            Lessons newLesson = new Lessons();
                            newLesson.setLessonName("Default Lesson");
                            newLesson.setClassStartTime("09:00");
                            newLesson.setClassFinishTime("10:00");
                            newLesson.setCabinet("101");
                            return lRepo.save(newLesson);
                        });
    }

    public Schedule findScheduleById(Long scheduleId){
        return shedRepo.findById(scheduleId)
                .orElseGet(() -> {
                    Schedule newSchedule = new Schedule();
                    newSchedule.setDayOfTheWeek("Monday");
                    newSchedule.setGroups(new ArrayList<>());
                    newSchedule.setTeachers(new ArrayList<>());
                    newSchedule.setLessons(new ArrayList<>());
                    return shedRepo.save(newSchedule);
                });
    }

    public Student findStudentById(Long studentId){
        return stRepo.findById(studentId)
                .orElseGet(() -> {
                    Student newStudent = new Student();
                    newStudent.setFirstName("Default First Name");
                    newStudent.setLastName("Default Last Name");
                    newStudent.setGroup(null);
                    newStudent.setAttendance(new ArrayList<>());
                    return stRepo.save(newStudent);
                });
    }

    public Teacher findTeacherById(Long teacherId){
        return tRepo.findById(teacherId)
                .orElseGet(() -> {
                    Teacher newTeacher = new Teacher();
                    newTeacher.setFirstName("Default First Name");
                    newTeacher.setLastName("Default Last Name");
                    newTeacher.setSchedule(null); // Установите расписание, если требуется.
                    newTeacher.setAttendance(new ArrayList<>());
                    return tRepo.save(newTeacher);
                });
    }
}
